package com.venturebackend.VentureBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VentureBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(VentureBackendApplication.class, args);
	}

}
