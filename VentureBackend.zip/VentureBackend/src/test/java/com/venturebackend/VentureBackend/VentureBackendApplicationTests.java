package com.venturebackend.VentureBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VentureBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
